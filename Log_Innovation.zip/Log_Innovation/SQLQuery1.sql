﻿GO
CREATE TRIGGER [dbo].[IncreaseSerials_App_Innovation]
	ON [dbo].[App_Innovation]
   After UPDATE
AS 
BEGIN	
	SET NOCOUNT ON;

declare		@Status varchar(50)
declare		@Ref_No varchar(50)
declare		@Approver_Remarks varchar(50)
declare		@OutPut varchar(255)
declare		@p1 varchar(255)


select @Status =Status from Inserted

select @Approver_Remarks =Approver_Remarks from Inserted
select @ID =ID from Inserted

IF (@Status= 'Pending for Approval' and @Approver_Remarks is null)
BEGIN
EXEC	[dbo].[GetAutoGenNumber_LIP]
		@p1='LIP',
		@OutPut = @OutPut OUTPUT
		Update App_Innovation set Ref_No=@OutPut where ID=@ID    

END
END