﻿
Go
CREATE TRIGGER [IncreaseSerials_App_Innovation]
	ON [dbo].[App_Innovation]
   INSTEAD OF INsert
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
SELECT * INTO #Inserted FROM Inserted

declare		@Ref_No varchar(50)
declare		@OutPut varchar(255)
declare		@p1 varchar(255)
declare		@ID UNIQUEIDENTIFIER

select @Ref_No =Ref_No from Inserted
select @ID =ID from Inserted


BEGIN
EXEC	[dbo].[GetAutoGenNumber_LIP]
		@p1='LIP',
		@OutPut = @OutPut OUTPUT

     UPDATE #Inserted SET Ref_No	 = @OutPut
     INSERT INTO App_Innovation SELECT * FROM #Inserted
END
 -- Insert statements for trigger here
END