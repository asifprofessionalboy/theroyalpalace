﻿using MailKit.Net.Smtp;
using MimeKit;
using MimeKit.Text;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

public class EmailService
{
	private readonly IConfiguration _configuration;

	public EmailService(IConfiguration configuration)
	{
		_configuration = configuration;
	}

	public async Task SendEmailAsync(string toEmail, string ccEmail, string bccEmail, string subject, string message)
	{
		var emailSettings = _configuration.GetSection("EmailSettings");

		var email = new MimeMessage();
		email.From.Add(new MailboxAddress(emailSettings["SenderName"], emailSettings["SenderEmail"]));
		email.To.Add(new MailboxAddress(toEmail, toEmail));
		if (!string.IsNullOrEmpty(ccEmail))
		{
			email.Cc.Add(new MailboxAddress(ccEmail, ccEmail));
		}
		if (!string.IsNullOrEmpty(bccEmail))
		{
			email.Bcc.Add(new MailboxAddress(bccEmail, bccEmail));
		}
		email.Subject = subject;
		email.Body = new TextPart(TextFormat.Html)
		{
			Text = message
		};

		using (var smtp = new SmtpClient())
		{
			smtp.Connect(emailSettings["SMTPServer"], int.Parse(emailSettings["SMTPPort"]), MailKit.Security.SecureSocketOptions.None);
			// Remove smtp.Authenticate() as no authentication is required
			await smtp.SendAsync(email);
			smtp.Disconnect(true);
		}
	}
}
