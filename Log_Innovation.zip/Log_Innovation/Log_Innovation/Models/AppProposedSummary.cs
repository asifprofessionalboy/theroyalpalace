﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppProposedSummary
    {
        public Guid Id { get; set; }
        public string? ProjectType { get; set; }
        public string? RefNo { get; set; }
        public string? NameOfProject { get; set; }
        public string? DescOfProject { get; set; }
        public string? BenefitToOrganisation { get; set; }
        public string? Attachments { get; set; }
        public string? Status { get; set; }
        public DateTime? DateOfLogging { get; set; }
        public string? LogBy { get; set; }
        public string? SubmitFlag { get; set; }
        public string? TangibleBenefits { get; set; }
        public string? IntangibleBenefits { get; set; }
        public string? Remarks { get; set; }
    }
}
