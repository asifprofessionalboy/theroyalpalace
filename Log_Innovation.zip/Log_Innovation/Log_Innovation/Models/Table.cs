﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class Table
    {
        public int Id { get; set; }
    }
}
