﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppProjectTeam
    {
        public Guid Id { get; set; }
        public Guid MasterId { get; set; }
        public string? Pno { get; set; }
        public string? EmployeeName { get; set; }
        public long? Contact { get; set; }
    }
}
