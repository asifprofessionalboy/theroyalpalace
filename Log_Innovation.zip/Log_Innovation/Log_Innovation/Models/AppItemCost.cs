﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppItemCost
    {
        public Guid Id { get; set; }
        public Guid MasterId { get; set; }
        public string? Item { get; set; }
        public string? Cost { get; set; }
    }
}
