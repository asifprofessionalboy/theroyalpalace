﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Log_Innovation.Models
{
    public partial class INNOVATIONDBContext : DbContext
    {
        public INNOVATIONDBContext()
        {
        }

        public INNOVATIONDBContext(DbContextOptions<INNOVATIONDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AppBenefitMaster> AppBenefitMasters { get; set; } = null!;
        public virtual DbSet<AppInnovation> AppInnovations { get; set; } = null!;
        public virtual DbSet<AppInnovationBenefit> AppInnovationBenefits { get; set; } = null!;
        public virtual DbSet<AppItemCost> AppItemCosts { get; set; } = null!;
        public virtual DbSet<AppProjectCategoryMaster> AppProjectCategoryMasters { get; set; } = null!;
        public virtual DbSet<AppProjectTeam> AppProjectTeams { get; set; } = null!;
        public virtual DbSet<AppProposedSummary> AppProposedSummaries { get; set; } = null!;
        public virtual DbSet<AppStageOfInnovationMaster> AppStageOfInnovationMasters { get; set; } = null!;
        public virtual DbSet<AppSysAutoNumber> AppSysAutoNumbers { get; set; } = null!;
        public virtual DbSet<AppUserroleMaster> AppUserroleMasters { get; set; } = null!;
        public virtual DbSet<Table> Tables { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AppBenefitMaster>(entity =>
            {
                entity.ToTable("App_Benefit_Master");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.Benefit)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppInnovation>(entity =>
            {
                entity.ToTable("App_Innovation");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ApprovedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ApprovedOn).HasColumnType("datetime");

                entity.Property(e => e.ApproverAttach)
                    .IsUnicode(false)
                    .HasColumnName("Approver_Attach");

                entity.Property(e => e.ApproverRemarks)
                    .IsUnicode(false)
                    .HasColumnName("Approver_Remarks");

                entity.Property(e => e.Attachment).IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Department)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.Designation)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Email_Id");

                entity.Property(e => e.Innovation)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OtherBenefit)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PersonalNo)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("Personal_No");

                entity.Property(e => e.RefNo)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("Ref_No");

                entity.Property(e => e.SourceOfInnovation)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Source_of_Innovation");

                entity.Property(e => e.StageOfInnovation)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Stage_of_Innovation");

                entity.Property(e => e.Status)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SubmitFlag)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Submit_Flag");
            });

            modelBuilder.Entity<AppInnovationBenefit>(entity =>
            {
                entity.ToTable("App_Innovation_Benefits");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Benefits)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MasterId).HasColumnName("Master_ID");
            });

            modelBuilder.Entity<AppItemCost>(entity =>
            {
                entity.ToTable("App_Item_Cost");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Cost)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Item)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MasterId).HasColumnName("MasterID");
            });

            modelBuilder.Entity<AppProjectCategoryMaster>(entity =>
            {
                entity.ToTable("App_ProjectCategory_Master");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.ProjectCategory)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppProjectTeam>(entity =>
            {
                entity.ToTable("App_Project_Team");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MasterId).HasColumnName("MasterID");

                entity.Property(e => e.Pno)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppProposedSummary>(entity =>
            {
                entity.ToTable("App_Proposed_Summary");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Attachments).IsUnicode(false);

                entity.Property(e => e.BenefitToOrganisation)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfLogging).HasColumnType("datetime");

                entity.Property(e => e.DescOfProject).IsUnicode(false);

                entity.Property(e => e.IntangibleBenefits)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Intangible_Benefits");

                entity.Property(e => e.LogBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NameOfProject)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProjectType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RefNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Remarks).IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SubmitFlag)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Submit_flag");

                entity.Property(e => e.TangibleBenefits)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Tangible_Benefits");
            });

            modelBuilder.Entity<AppStageOfInnovationMaster>(entity =>
            {
                entity.ToTable("App_StageOfInnovation_Master");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.StageOfInnovation)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppSysAutoNumber>(entity =>
            {
                entity.HasKey(e => e.ObjName);

                entity.ToTable("App_Sys_AutoNumber");

                entity.Property(e => e.ObjName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Leftpadding)
                    .HasColumnName("leftpadding")
                    .HasDefaultValueSql("((5))");

                entity.Property(e => e.Number).HasColumnName("number");

                entity.Property(e => e.Postfix)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Prefix)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppUserroleMaster>(entity =>
            {
                entity.ToTable("App_Userrole_Master");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Pno)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProjectCategory)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Table>(entity =>
            {
                entity.ToTable("Table");

                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
