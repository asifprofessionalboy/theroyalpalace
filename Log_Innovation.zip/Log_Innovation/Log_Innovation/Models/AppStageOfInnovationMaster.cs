﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppStageOfInnovationMaster
    {
        public Guid Id { get; set; }
        public string? StageOfInnovation { get; set; }
        public int? SlNo { get; set; }
    }
}
