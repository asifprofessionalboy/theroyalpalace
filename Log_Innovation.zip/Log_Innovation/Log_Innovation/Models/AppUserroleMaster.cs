﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppUserroleMaster
    {
        public Guid Id { get; set; }
        public string? ProjectCategory { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string? Pno { get; set; }
    }
}
