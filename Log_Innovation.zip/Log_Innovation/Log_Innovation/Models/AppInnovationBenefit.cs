﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppInnovationBenefit
    {
        public Guid Id { get; set; }
        public Guid MasterId { get; set; }
        public string? Benefits { get; set; }
    }
}
