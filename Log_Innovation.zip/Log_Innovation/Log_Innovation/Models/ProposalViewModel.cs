﻿namespace Log_Innovation.Models
{
    public class ProposalViewModel
    {

        public ProposalViewModel()
        {
            ItemCosts = new List<AppItemCost>();
            ProposedSummary = new AppProposedSummary();
            appProjectTeams= new List<AppProjectTeam>();
        }

        public List<AppItemCost> ItemCosts { get; set; } = new List<AppItemCost>();
        public AppProposedSummary ProposedSummary { get; set; }
        public List<AppProjectTeam> appProjectTeams { get; set; }
        public Guid Id { get; set; }
        public Guid MasterId { get; set; }
        public string? Item { get; set; }
        public string? Cost { get; set; }


        public Guid ItemId { get; set; }
        public Guid ItemMasterId { get; set; }
        public string? Pno { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }

        public Guid ProposalId { get; set; }
        public string? ProjectType { get; set; }
        public string? RefNo { get; set; }
        public string? NameOfProject { get; set; }
        public string? DescOfProject { get; set; }
        public string? BenefitToOrganisation { get; set; }
        public string? Attachments { get; set; }

        public IEnumerable<IFormFile>? Attach { get; set; }
        public string? Status { get; set; }
        public string? DateOfLogging { get; set; }
        public string? LogBy { get; set; }
        public string? SubmitFlag { get; set; }

        public string? TangibleBenefits { get; set; }
        public string? IntangibleBenefits { get; set; }
        public string? Remarks { get; set; }
    }
    
}
 

