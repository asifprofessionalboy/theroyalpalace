﻿namespace Log_Innovation.Models
{
    public class InnovationViewModel
    {
        public InnovationViewModel() 
        {
            appInnovationBenefits = new List<AppInnovationBenefit>();
            AppInnovation = new AppInnovation();    
            appProjectTeams= new List<AppProjectTeam>();
            
        }

        public List<AppInnovationBenefit> appInnovationBenefits { get; set; }

        public AppInnovation AppInnovation { get; set; }    

        public List<AppProjectTeam> appProjectTeams { get; set; }

        public Guid? Id { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string? PersonalNo { get; set; }
        public string? Name { get; set; }
        public string? Department { get; set; }
        public string? Designation { get; set; }
        public string? EmailId { get; set; }
        public long? Mobile { get; set; }
        public string? Innovation { get; set; }
        public string? Description { get; set; }
		public string? OtherBenefit { get; set; }
		public string? StageOfInnovation { get; set; }
		public string? SourceOfInnovation { get; set; }
		public string? Attachment { get; set; }

        public IEnumerable<IFormFile>? Attach { get; set; }
        public string? Status { get; set; }
        public string? RefNo { get; set; }
        public string? ApproverRemarks { get; set; }
        public string? ApproverAttach { get; set; }
		public IEnumerable<IFormFile>? ApproverAttachment { get; set; }
		public string? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public string? SubmitFlag { get; set; }

        //Innovation Benefits

        public Guid BenefitId { get; set; }
        public Guid MasterId { get; set; }
        public string? Benefits { get; set; }

        public Guid TeamId { get; set; }
        public Guid TeamMasterId { get; set; }
        public string? Pno { get; set; }
		public string? EmployeeName { get; set; }
		public long? Contact { get; set; }
    }
}
