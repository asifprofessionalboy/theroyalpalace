﻿using Microsoft.AspNetCore.Mvc;

namespace Log_Innovation.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Homepage()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Logout()
        {
            return RedirectToAction("Login", "User");
           
        }

    }
}
