﻿using System.Reflection.Emit;
using System.Xml.Linq;
using Log_Innovation.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Log_Innovation.Controllers
{
	public class InnovationController : Controller
	{
		private readonly INNOVATIONDBContext context;
		private readonly UserLoginDBContext context1;
		private readonly IConfiguration configuration;
		private readonly EmailService emailService;

		public InnovationController(INNOVATIONDBContext context, UserLoginDBContext context1, IConfiguration configuration, EmailService emailService)
		{
			this.context = context;
			this.context1 = context1;
			this.configuration = configuration;
			this.emailService = emailService;
		}

		public IActionResult Innovation_Request()
		{

			var viewModel = new InnovationViewModel
			{
				appInnovationBenefits = new List<AppInnovationBenefit>(),
				appProjectTeams = new List<AppProjectTeam>(),
				Attach = new List<IFormFile>(),
				
			};

			var Data = context1.AppEmployeeMasters.ToList();
			ViewBag.data = Data;

			var Benefit = context.AppBenefitMasters.Select(x => x.Benefit).ToList();
			var Benefitdd = Benefit.Select(name => new SelectListItem
			{
				Value = name,
				Text = name
			}).ToList();
			ViewBag.DDList = Benefitdd;

			var InnovationStage = context.AppStageOfInnovationMasters.Select(x => new
			{
				StageOfInnovation = x.StageOfInnovation,
				SlNo = x.SlNo,
			}).ToList().OrderBy(x => x.SlNo);

			var InnovationStagedd = InnovationStage.Select(name => new SelectListItem
			{
				Value = name.StageOfInnovation,
				Text = name.StageOfInnovation
			}).ToList();
			ViewBag.InnovationDDList = InnovationStagedd;


			var pnoDetails = context1.AppEmployeeMasters
						 .Select(x => new
						 {
							 Pno = x.Pno,
							 Ename = x.Ename,
							 DepartmentName = x.DepartmentName,
							 EmailId = x.EmailId,
							 Phone = x.Phone,
							 Designation = x.Designation
						 }).ToList();

			ViewBag.PnoList = pnoDetails;

			var PnoEnameList = context1.AppEmployeeMasters
						 .Select(x => new
						 {
							 Pno = x.Pno,
							 Ename = x.Ename,
							 Contact = x.Phone
						 })
						 .ToList();

			ViewBag.PnoEnameList = PnoEnameList;

			return View(viewModel);
		}

		[HttpPost]

		public async Task<IActionResult> Innovation_Request(InnovationViewModel InnViewModel, string action)
		{
			try
			{
				if (ModelState.IsValid)
				{
					if (InnViewModel.Attach != null && InnViewModel.Attach.Any())
					{
						var uploadPath = configuration["FileUpload:Path"];
						foreach (var file in InnViewModel.Attach)
						{
							if (file.Length > 0)
							{
								var uniqueId = Guid.NewGuid().ToString();
								var currentDateTime = DateTime.UtcNow.ToString("dd-MM-yyyy_HH-mm-ss");
								var originalFileName = Path.GetFileNameWithoutExtension(file.FileName);
								var fileExtension = Path.GetExtension(file.FileName);
								var formattedFileName = $"{uniqueId}_{currentDateTime}_{originalFileName}{fileExtension}";
								var fullPath = Path.Combine(uploadPath, formattedFileName);

								using (var stream = new FileStream(fullPath, FileMode.Create))
								{
									await file.CopyToAsync(stream);
								}

								InnViewModel.Attachment += $"{formattedFileName},";
							}
						}

						if (!string.IsNullOrEmpty(InnViewModel.Attachment))
						{
							InnViewModel.Attachment = InnViewModel.Attachment.TrimEnd(',');
						}
					}
					var newBenefit = new AppBenefitMaster
					{
						Id = Guid.NewGuid(),
						Benefit = InnViewModel.OtherBenefit, 
						
					};

					context.AppBenefitMasters.Add(newBenefit);

					var Innovation = new AppInnovation
					{
						Id = Guid.NewGuid(),
						CreatedBy = InnViewModel.CreatedBy,
						CreatedOn = DateTime.Now,
						PersonalNo = InnViewModel.PersonalNo,
						Name = InnViewModel.Name,
						Department = InnViewModel.Department,
						Designation = InnViewModel.Designation,
						EmailId = InnViewModel.EmailId,
						Mobile = InnViewModel.Mobile,
						Innovation = InnViewModel.Innovation,
						Description = InnViewModel.Description,
						StageOfInnovation = InnViewModel.StageOfInnovation,
						Attachment = InnViewModel.Attachment,
						Status = InnViewModel.Status,
						RefNo = InnViewModel.RefNo,
						SubmitFlag = InnViewModel.SubmitFlag,
						SourceOfInnovation = InnViewModel.SourceOfInnovation,
						OtherBenefit = InnViewModel.OtherBenefit,

					};
					InnViewModel.AppInnovation = Innovation;

					if (Innovation.SubmitFlag == "Submit")
					{
						Innovation.Status = "Pending for Approval";
					}
					else if (Innovation.SubmitFlag == "Save as Draft")
					{
						Innovation.Status = "Draft";
					}

					

					//var benefittype = Request.Form["action"];

					//if(benefittype == "Submit")
					//{
					//	Innovation.Status = "Pending for Approval";
					//}
					//else if (benefittype == "Save as Draft")
					//{
					//	Innovation.Status = "Pending for Approval";
					//}


					context.AppInnovations.Add(Innovation);
					await context.SaveChangesAsync();



					foreach (var benefit in InnViewModel.appInnovationBenefits)
					{
						benefit.Id = Guid.NewGuid();
						benefit.MasterId = InnViewModel.AppInnovation.Id;
						await context.AppInnovationBenefits.AddAsync(benefit);
					}
					await context.SaveChangesAsync();

					foreach (var team in InnViewModel.appProjectTeams)
					{
						team.Id = Guid.NewGuid();
						team.MasterId = InnViewModel.AppInnovation.Id;
						await context.AppProjectTeams.AddAsync(team);
					}
					await context.SaveChangesAsync();


					var refNo = context.AppInnovations
				.Where(x => x.Id == Innovation.Id)
				.Select(x => new
				{
					Name = x.Name,
					Dept = x.Department,
					RefNo = x.RefNo,
					Innovation = x.Innovation
				}).FirstOrDefault();



					if (refNo != null)
					{

						string subject = refNo.Name + ": has logged an Innovation ";
						string msg = "</BR>" + refNo.Name + "(" + refNo.Dept + ")" + ",has logged the following Innovation." + "<BR /> "
									  + "Innovation Id : " + refNo.RefNo + "<BR />"
									  + "Innovation : " + refNo.Innovation + "<BR />" +
									  "</BR>Click here to view the Innovation: http://localhost/Log_Innovation <BR />" +
									 "Regards <BR />" +
									 "Sashi Kumar<BR />";

						// Send the email
						await emailService.SendEmailAsync("shashi.kumar@tatasteel.com", "irshad321mhan@gmail.com", "", subject, msg);
					}

					return RedirectToAction("HomePage", "Master");
				}


			}
			catch (Exception ex)
			{
				ex.Message.ToString();
			}


			return View(InnViewModel);
		}


		public async Task<IActionResult> Approval_Form(Guid? id, int page = 1, string searchString = "")
		{
			int pageSize = 5;
			var query = context.AppInnovations.Where(x => x.Status == "Pending for Approval").AsQueryable();
			if (!string.IsNullOrEmpty(searchString))
			{
				query = query.Where(a => a.RefNo.Contains(searchString));
			}
			var PagedData = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();
			var TotalCount = query.Count();
			ViewBag.ListData2 = PagedData;
			ViewBag.CurrentPage = page;
			ViewBag.TotalPages = (int)Math.Ceiling(TotalCount / (double)pageSize);
			ViewBag.SearchString = searchString;

			var viewModel = new InnovationViewModel
			{
				appInnovationBenefits = new List<AppInnovationBenefit>(),
				appProjectTeams = new List<AppProjectTeam>(),
				Attach = new List<IFormFile>(),
				Attachment = string.Empty,
			};

			if (id.HasValue)
			{
				var model = await context.AppInnovations.FindAsync(id.Value);
				if (model == null)
				{
					return NotFound();
				}

				// Fetch the benefits associated with the innovation
				var benefits = await context.AppInnovationBenefits
					.Where(b => b.MasterId == model.Id)
					.ToListAsync();

				var teams = await context.AppProjectTeams
					.Where(t => t.MasterId == model.Id)
					.ToListAsync();

				viewModel = new InnovationViewModel
				{
					PersonalNo = model.PersonalNo,
					Name = model.Name,
					Department = model.Department,
					Designation = model.Designation,
					EmailId = model.EmailId,
					Mobile = model.Mobile,
					Innovation = model.Innovation,
					Description = model.Description,
					StageOfInnovation = model.StageOfInnovation,
					SourceOfInnovation = model.SourceOfInnovation,
					Attachment = model.Attachment,
					appInnovationBenefits = benefits,
					appProjectTeams = teams,
					ApproverRemarks = model.ApproverRemarks,
					ApproverAttach = model.ApproverAttach,
					OtherBenefit = model.OtherBenefit
				};



				var InnovationStage = context.AppStageOfInnovationMasters.Select(x => new
				{
					StageOfInnovation = x.StageOfInnovation,
					SlNo = x.SlNo,
				}).ToList().OrderBy(x => x.SlNo);

				var InnovationStagedd = InnovationStage.Select(name => new SelectListItem
				{
					Value = name.StageOfInnovation,
					Text = name.StageOfInnovation
				}).ToList();
				ViewBag.InnovationDDList = InnovationStagedd;

				var Benefit = context.AppBenefitMasters.Select(x => x.Benefit).ToList();
				var Benefitdd = Benefit.Select(name => new SelectListItem
				{
					Value = name,
					Text = name
				}).ToList();
				ViewBag.DDList = Benefitdd;

				var PnoEnameList = context1.AppEmployeeMasters
					 .Select(x => new
					 {
						 Pno = x.Pno,
						 Ename = x.Ename,
						 Contact = x.Phone
					 })
					 .ToList();

				ViewBag.PnoEnameList = PnoEnameList;
			}

			ViewBag.ListData = context.AppInnovations.Where(x => x.Status == "Pending for Approval").ToList();
			return View(viewModel);
		}

		[HttpPost]
		public async Task<IActionResult> Approval_Form(InnovationViewModel InnViewModel)
		{
			if (ModelState.IsValid)
			{
				// Handle new Attach files (if any)
				if (InnViewModel.Attach != null && InnViewModel.Attach.Any())
				{
					var uploadPath = configuration["FileUpload:Path"];
					foreach (var file in InnViewModel.Attach)
					{
						if (file.Length > 0)
						{
							var uniqueId = Guid.NewGuid().ToString();
							var currentDateTime = DateTime.UtcNow.ToString("dd-MM-yyyy");
							var originalFileName = Path.GetFileNameWithoutExtension(file.FileName);
							var fileExtension = Path.GetExtension(file.FileName);
							var formattedFileName = $"{uniqueId}_{currentDateTime}_{originalFileName}{fileExtension}";
							var fullPath = Path.Combine(uploadPath, formattedFileName);
							using (var stream = new FileStream(fullPath, FileMode.Create))
							{
								await file.CopyToAsync(stream);
							}
							InnViewModel.Attachment += $"{formattedFileName},";
						}
					}
					if (!string.IsNullOrEmpty(InnViewModel.Attachment))
					{
						InnViewModel.Attachment = InnViewModel.Attachment.TrimEnd(',');
					}
				}
				else if (InnViewModel.Id.HasValue)
				{
					// Retrieve existing attachments from database if no new attachments are uploaded
					var existingInnovation2 = await context.AppInnovations.FindAsync(InnViewModel.Id.Value);
					if (existingInnovation2 != null)
					{
						InnViewModel.Attachment = existingInnovation2.Attachment;
					}
				}

				var Status = Request.Form["Champion"];

				if (!InnViewModel.Id.HasValue)
				{
					ModelState.AddModelError("", "Invalid operation. The innovation Id is required.");
					return View(InnViewModel);
				}

				var existingInnovation = await context.AppInnovations.FindAsync(InnViewModel.Id.Value);

				if (existingInnovation == null)
				{
					return NotFound();
				}

				// Update the existing innovation entity with new values
				existingInnovation.PersonalNo = InnViewModel.PersonalNo;
				existingInnovation.Name = InnViewModel.Name;
				existingInnovation.Department = InnViewModel.Department;
				existingInnovation.Designation = InnViewModel.Designation;
				existingInnovation.EmailId = InnViewModel.EmailId;
				existingInnovation.Mobile = InnViewModel.Mobile;
				existingInnovation.Innovation = InnViewModel.Innovation;
				existingInnovation.Description = InnViewModel.Description;
				existingInnovation.StageOfInnovation = InnViewModel.StageOfInnovation;
				existingInnovation.Attachment = InnViewModel.Attachment;
				existingInnovation.Status = Status;
				existingInnovation.ApproverRemarks = InnViewModel.ApproverRemarks;
				existingInnovation.SubmitFlag = "Submit";
				existingInnovation.ApprovedOn = DateTime.Now;
				existingInnovation.SourceOfInnovation = InnViewModel.SourceOfInnovation;
				existingInnovation.OtherBenefit = InnViewModel.OtherBenefit;

				try
				{
					context.Entry(existingInnovation).State = EntityState.Modified;
					await context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException ex)
				{
					ModelState.AddModelError("", "Unable to save changes. The innovation was updated or deleted by another user.");
					return View(InnViewModel);
				}

				// Update or insert benefits
				foreach (var benefit in InnViewModel.appInnovationBenefits)
				{
					if (benefit.Id == Guid.Empty)
					{
						benefit.Id = Guid.NewGuid();
						benefit.MasterId = existingInnovation.Id;
						await context.AppInnovationBenefits.AddAsync(benefit);
					}
					else
					{
						benefit.MasterId = existingInnovation.Id;
						context.Entry(benefit).State = EntityState.Modified;
					}
				}
				await context.SaveChangesAsync();

				// Update or insert team members
				foreach (var team in InnViewModel.appProjectTeams)
					{
					if (team.Id == Guid.Empty)
					{
						team.Id = Guid.NewGuid();
						team.MasterId = existingInnovation.Id;
						await context.AppProjectTeams.AddAsync(team);
					}
					else
					{
						team.MasterId = existingInnovation.Id;
						context.Entry(team).State = EntityState.Modified;
					}
				}
				await context.SaveChangesAsync();

				var refNo = await context.AppInnovations
					.Where(x => x.Id == existingInnovation.Id)
					.Select(x => x.RefNo)
					.FirstOrDefaultAsync();

				var status = await context.AppInnovations
					.Where(x => x.Id == existingInnovation.Id)
					.Select(x => x.Status)
					.FirstOrDefaultAsync();

				if (refNo != null)
				{
					string statusText = status switch
					{
						"Approved" => "Approved",
						"Pending With Requester" => "Returned",
						"Rejected" => "Rejected",
						_ => "Unknown"
					};

					string subject = "Innovation Log: RefNo " + refNo;
					string msg = $"<html><body><P><B>"
									+ $"Innovation is {statusText} with RefNo: {refNo}<BR /> "
									+ "Kindly do the needful<BR /> "
									+ "LOG INNOVATION: http://10.0.168.68/Log_Innovation <BR />"
									+ " Thanks & Regards";
		
		   //await emailService.SendEmailAsync("shashi.kumar@tatasteel.com", "irshad321mhan@gmail.com", "", subject, msg);
		}
			}

			return RedirectToAction("HomePage","Master");
		}


		public async Task<IActionResult> AllRequest(Guid? id, int page = 1, string searchString = "")
		{

			int pageSize = 5;
			var query = context.AppInnovations.AsQueryable();
			if (!string.IsNullOrEmpty(searchString))
			{
				query = query.Where(a => a.RefNo.Contains(searchString));
			}
			var PagedData = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();
			var TotalCount = query.Count();
			ViewBag.ListData = PagedData;
			ViewBag.CurrentPage = page;
			ViewBag.TotalPages = (int)Math.Ceiling(TotalCount / (double)pageSize);
			ViewBag.SearchString = searchString;

			var viewModel = new InnovationViewModel
			{
				appInnovationBenefits = new List<AppInnovationBenefit>(),
				Attach = new List<IFormFile>(),
				Attachment = string.Empty,
			};

			if (id.HasValue)
			{
				var model = await context.AppInnovations.FindAsync(id.Value);
				if (model == null)
				{
					return NotFound();
				}
				var benefits = await context.AppInnovationBenefits
				   .Where(b => b.MasterId == model.Id)
				   .ToListAsync();

				viewModel = new InnovationViewModel
				{
					PersonalNo = model.PersonalNo,
					Name = model.Name,
					Department = model.Department,
					Designation = model.Designation,
					EmailId = model.EmailId,
					Mobile = model.Mobile,
					Innovation = model.Innovation,
					Description = model.Description,
					StageOfInnovation = model.StageOfInnovation,
					Attachment = model.Attachment,
					appInnovationBenefits = benefits,
					ApproverRemarks = model.ApproverRemarks,
					ApproverAttach = model.ApproverAttach
				};

			}
			//var pnoEnameList = context1.AppEmployeeMasters
			//			.Select(x => new
			//			{
			//				Pno = x.Pno,
			//				Ename = x.Ename,
			//				DepartmentName = x.DepartmentName,
			//				EmailId = x.EmailId,
			//				Phone = x.Phone,
			//				Designation = x.Designation
			//			}).ToList();

			//ViewBag.PnoList = pnoEnameList;


			var InnovationStage = context.AppStageOfInnovationMasters.Select(x => x.StageOfInnovation).ToList();
			var InnovationStagedd = InnovationStage.Select(name => new SelectListItem
			{
				Value = name,
				Text = name
			}).ToList();
			ViewBag.InnovationDDList = InnovationStagedd;

			return View(viewModel);
		}

		[HttpPost]
		public async Task<IActionResult> AllRequest(InnovationViewModel InnViewModel)
		{
			if (ModelState.IsValid)
			{
				if (InnViewModel.Attach != null && InnViewModel.Attach.Any())
				{
					var uploadPath = configuration["FileUpload:Path"];
					foreach (var file in InnViewModel.Attach)
					{
						if (file.Length > 0)
						{
							var uniqueId = Guid.NewGuid().ToString();
							var currentDateTime = DateTime.UtcNow.ToString("dd-MM-yyyy");
							var originalFileName = Path.GetFileNameWithoutExtension(file.FileName);
							var fileExtension = Path.GetExtension(file.FileName);
							var formattedFileName = $"{uniqueId}_{currentDateTime}_{originalFileName}{fileExtension}";
							var fullPath = Path.Combine(uploadPath, formattedFileName);
							using (var stream = new FileStream(fullPath, FileMode.Create))
							{
								await file.CopyToAsync(stream);
							}
							InnViewModel.Attachment += $"{formattedFileName},";
						}
					}
					if (!string.IsNullOrEmpty(InnViewModel.Attachment))
					{
						InnViewModel.Attachment = InnViewModel.Attachment.TrimEnd(',');
					}
				}
				else if (InnViewModel.Id.HasValue)
				{
					// Retrieve existing attachments from database if no new attachments are uploaded
					var existingInnovation2 = await context.AppInnovations.FindAsync(InnViewModel.Id.Value);
					if (existingInnovation2 != null)
					{
						InnViewModel.Attachment = existingInnovation2.Attachment;
					}
				}

			}
			return View();
		}
		public IActionResult DownloadFile(string fileName)
		{
			var uploadPath = configuration["FileUpload:Path"];
			var filePath = Path.Combine(uploadPath, fileName);

			if (!System.IO.File.Exists(filePath))
			{
				return NotFound();
			}

			var memory = new MemoryStream();
			using (var stream = new FileStream(filePath, FileMode.Open))
			{
				stream.CopyTo(memory);
			}
			memory.Position = 0;

			return File(memory, GetContentType(filePath), Path.GetFileName(filePath));
		}

		private string GetContentType(string path)
		{
			var types = GetMimeTypes();
			var ext = Path.GetExtension(path).ToLowerInvariant();
			return types[ext];
		}

		private Dictionary<string, string> GetMimeTypes()
		{
			return new Dictionary<string, string>
	{
		{ ".txt", "text/plain" },
		{ ".pdf", "application/pdf" },
		{ ".doc", "application/vnd.ms-word" },
		{ ".docx", "application/vnd.ms-word" },
		{ ".xls", "application/vnd.ms-excel" },
		{ ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
		{ ".png", "image/png" },
		{ ".jpg", "image/jpeg" },
		{ ".jpeg", "image/jpeg" },
		{ ".gif", "image/gif" },
		{ ".csv", "text/csv" }
	};
		}
	}
}
