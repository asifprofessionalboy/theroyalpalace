﻿using System.Diagnostics;
using Log_Innovation.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Log_Innovation.Controllers
{
    public class MasterController : Controller
    {
        private readonly INNOVATIONDBContext context;
        private readonly UserLoginDBContext context1;

        public MasterController(INNOVATIONDBContext context, UserLoginDBContext context1)
        {
            this.context = context;
            this.context1 = context1;
        }

        public IActionResult Homepage()
        {
            return View();
        }

        public IActionResult ProjectCategory(Guid? id)
        {
            var List = context.AppProjectCategoryMasters.ToList();
            ViewBag.data2 = List;

            AppProjectCategoryMaster model = new AppProjectCategoryMaster();
            if (id.HasValue)
            {
                model = context.AppProjectCategoryMasters.Find(id.Value);
                if (model == null)
                {
                    return NotFound();
                }
            }
            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult> ProjectCategory(AppProjectCategoryMaster categoryMaster)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (categoryMaster.Id == Guid.Empty)
                    {
                        var Data = context.AppProjectCategoryMasters.FirstOrDefault(x => x.ProjectCategory == categoryMaster.ProjectCategory);
                        if (Data != null)
                        {
                            ViewBag.DupMsg = "Data is Already Exist";
                        }
                        else
                        {
                            categoryMaster.Id = Guid.NewGuid();
                            categoryMaster.CreatedOn = DateTime.Now;
                            context.AppProjectCategoryMasters.Add(categoryMaster);
                        }
                    }
                    else
                    {
                        context.AppProjectCategoryMasters.Update(categoryMaster);
                    }
                    await context.SaveChangesAsync();
                    return RedirectToAction("ProjectCategory");
                    
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return View(categoryMaster);
        }
        public IActionResult ProjectCategoryEdit(Guid id)
        {
                var Data = context.AppProjectCategoryMasters.Find(id);
                return View(Data);
           
        }
        [HttpPost]
        public async Task<IActionResult> ProjectCategoryEdit(Guid id, AppProjectCategoryMaster categoryMaster)
        {
            context.AppProjectCategoryMasters.Update(categoryMaster);
            await context.SaveChangesAsync();
            return RedirectToAction("ProjectCategory");
        }

        [HttpPost]
        public async Task<IActionResult> ProjectCategoryDelete(Guid id)
        {
            if (id == Guid.Empty)
            {
                return BadRequest("Invalid ID");
            }

            var data = await context.AppProjectCategoryMasters.FindAsync(id);
            if (data == null)
            {
                return NotFound();
            }

            context.AppProjectCategoryMasters.Remove(data);
            await context.SaveChangesAsync();

            return Ok();
        }



        public IActionResult Userrole(Guid? id)
        {
           
    
            var userRoleList = context.AppUserroleMasters.ToList();

            ViewBag.userlist = userRoleList;

            var pnoEnameList = context1.AppEmployeeMasters
                                     .Select(x => new
                                     {
                                         Pno = x.Pno,
                                         Ename = x.Ename,
                                         DisplayText = $"{x.Ename} - ({x.Pno})"
                                     })
                                     .ToList();


            var selectList = pnoEnameList.Select(x => new SelectListItem
            {
                Value = x.Pno.ToString(), // Assuming Pno is of a numeric type, if not use .ToString() method accordingly
                Text = x.DisplayText
            }).ToList();
            ViewBag.PnoEname = selectList;

            var projectCategoryList = context.AppProjectCategoryMasters
                                                 .Select(x => x.ProjectCategory)
                                                 .Select(name => new SelectListItem
                                                 {
                                                     Value = name,
                                                     Text = name
                                                 }).ToList();
            ViewBag.UserRole = projectCategoryList;

            AppUserroleMaster model = new AppUserroleMaster();
            if (id.HasValue)
            {
                model = context.AppUserroleMasters.Find(id.Value);
                if (model == null)
                {
                    return NotFound();
                }
                return View(model);
            }


            return View();

        }
        [HttpPost]
        public async Task<IActionResult> Userrole(AppUserroleMaster userrole)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (userrole.Id == Guid.Empty)
                    {

                        var Data = context.AppUserroleMasters.FirstOrDefault(x => x.ProjectCategory == userrole.ProjectCategory && x.Pno == userrole.Pno);
                        if (Data != null)
                        {
                            ViewBag.DupMsg = "Data is Already Exist";
                        }
                        else
                        {
                            userrole.Id = Guid.NewGuid();
                            userrole.CreatedOn = DateTime.Now;
                            context.AppUserroleMasters.Add(userrole);
                            await context.SaveChangesAsync();
                            return RedirectToAction("userrole");
                        }
                    }
                    else
                    {
                        context.AppUserroleMasters.Update(userrole);
                    }
                    await context.SaveChangesAsync();
                    return RedirectToAction("Userrole");

                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred: " + ex.Message);
            }
            return View(userrole);
        }

        public IActionResult UserroleEdit(Guid id)
        {
            var Data = context.AppUserroleMasters.Find(id);
            return View(Data);

        }
        [HttpPost]
        public async Task<IActionResult> UserroleEdit(Guid id, AppUserroleMaster userrole)
        {
            context.AppUserroleMasters.Update(userrole);
            await context.SaveChangesAsync();
            return RedirectToAction("Userrole");
        }

        [HttpGet]
        public async Task<IActionResult> UserRoleDelete(Guid Id)
        {
            var Data = await context.AppUserroleMasters.FindAsync(Id);
            if (Data == null)
            {
                return NotFound();
            }
            context.AppUserroleMasters.Remove(Data);
            await context.SaveChangesAsync();
            return Ok();
        }

    }
}
