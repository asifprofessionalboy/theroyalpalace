﻿using System.IO;
using Log_Innovation.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Log_Innovation.Controllers
{
    public class ProposalController : Controller
    {
        private readonly INNOVATIONDBContext context;
        private readonly UserLoginDBContext context1;
        private readonly IConfiguration configuration;

        public ProposalController(INNOVATIONDBContext context, UserLoginDBContext context1,IConfiguration configuration)
        {
            this.context = context;
            this.context1 = context1;
            this.configuration = configuration;
        }

        public IActionResult Proposal()
        {
            var Data = context.AppProposedSummaries.ToList();
            ViewBag.Data = Data;

            var viewModel = new ProposalViewModel
            {
                ItemCosts = new List<AppItemCost>(),
                appProjectTeams = new List<AppProjectTeam>()
            };

            var LogIn = DateTime.Today.ToString("dd/MM/yyyy");
            ViewBag.Log = LogIn;

            var projectCategoryList = context.AppProjectCategoryMasters
                                                  .Select(x => x.ProjectCategory)
                                                  .Select(name => new SelectListItem
                                                  {
                                                      Value = name,
                                                      Text = name
                                                  }).ToList();
            ViewBag.ProjectCategory = projectCategoryList;

            var pnoEnameList = context1.AppEmployeeMasters
                         .Select(x => new
                         {
                             Pno = x.Pno,
                             Ename = x.Ename,
                         })
                         .ToList();

            ViewBag.PnoEnameList = pnoEnameList;



            return View(viewModel);
        }
        [HttpPost]

        public async Task<IActionResult> Proposal(ProposalViewModel viewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (viewModel.Attach != null && viewModel.Attach.Any())
                    {
                        var uploadPath = configuration["FileUpload:Path"];
                        foreach (var file in viewModel.Attach)
                        {
                            if (file.Length > 0)
                            {
                                var uniqueId = Guid.NewGuid().ToString();
                                var currentDateTime = DateTime.UtcNow.ToString("dd-MM-yyyy:HH-mm-ss");
                                var originalFileName = Path.GetFileNameWithoutExtension(file.FileName);
                                var fileExtension = Path.GetExtension(file.FileName);
                                var formattedFileName = $"{uniqueId}_{currentDateTime}_{originalFileName}{fileExtension}";
                                var fullPath = Path.Combine(uploadPath, formattedFileName);
                                using (var stream = new FileStream(fullPath, FileMode.Create))
                                {
                                    await file.CopyToAsync(stream);
                                }

                                viewModel.Attachments += $"{formattedFileName},";
                            }
                        }

                        if (!string.IsNullOrEmpty(viewModel.Attachments))
                        {
                            viewModel.Attachments = viewModel.Attachments.TrimEnd(',');
                        }
                    }
                    var benefittype = Request.Form["benefitType"];

                    var AppProposed = new AppProposedSummary
                    {
                        Id = Guid.NewGuid(),
                        DateOfLogging = DateTime.Now,
                        ProjectType = viewModel.ProjectType,
                        NameOfProject = viewModel.NameOfProject,
                        DescOfProject = viewModel.DescOfProject,
                        BenefitToOrganisation = benefittype,
                        Attachments = viewModel.Attachments,
                        LogBy = viewModel.LogBy,
                        SubmitFlag = viewModel.SubmitFlag,
                        Status = viewModel.Status,
                        IntangibleBenefits = viewModel.IntangibleBenefits,
                        TangibleBenefits = viewModel.TangibleBenefits,
                        Remarks = viewModel.Remarks
                        
                        
                    };

                    viewModel.ProposedSummary = AppProposed; // Assign to viewModel.ProposedSummary

                    if (AppProposed.SubmitFlag == "Submit")
                    {
                        AppProposed.Status = "Pending for Approval";
                    }
                    else if (AppProposed.SubmitFlag == "Save as Draft")
                    {
                        AppProposed.Status = "Draft";
                    }


                    context.AppProposedSummaries.Add(AppProposed);
                    await context.SaveChangesAsync();


                    foreach (var itemCost in viewModel.ItemCosts)
                    {
                        itemCost.Id = Guid.NewGuid();
                        itemCost.MasterId = viewModel.ProposedSummary.Id;
                        await context.AppItemCosts.AddAsync(itemCost);
                    }

                    await context.SaveChangesAsync();

                    foreach (var projectTeam in viewModel.appProjectTeams)
                    {
                        projectTeam.Id = Guid.NewGuid();
                        projectTeam.MasterId = viewModel.ProposedSummary.Id;
                        await context.AppProjectTeams.AddAsync(projectTeam);
                    }

                    await context.SaveChangesAsync();


                    return RedirectToAction("Proposal");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred: " + ex.Message);
            }

            return View(viewModel);
        }

    }
}
