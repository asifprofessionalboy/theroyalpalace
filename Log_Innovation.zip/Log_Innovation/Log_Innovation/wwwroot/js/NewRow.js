﻿
document.getElementById('add-row-btn2').addEventListener('click', function ()
{
    var container = document.getElementById('rows-container2');
    var rowCount = container.children.length;
    console.log('Current row count:', rowCount); // Debugging log

    var newRow = document.createElement('div');
    newRow.classList.add('card', 'rounded-j');
    newRow.setAttribute('data-index', rowCount);
    newRow.innerHTML = `
   <div class="row">
        <div class="col-md-2">

                        <div class="form-group">
                        <label class="control-label">Item</label>
                            <input class="form-control" type="text" name="ItemCosts[${rowCount}].Item" />
                         </div>
         </div>

                   
        <div class="col-md-2">

                        <div class="form-group">
                            <label class="control-label">Cost</label>
                            <input class="form-control num" step="0.01" Type="number" name="ItemCosts[${rowCount}].Cost" />
                        </div>
</div>
 <div class="col-md-2">

                        <div class="form-group">
							<i class="fa fa-times fa-lg" aria-hidden="true" style="color:red;margin-top:25px;"></i>
						</div>
						
                  
        </div>
</div>
        `;

    container.appendChild(newRow);
    newRow.querySelector('.fa-times').addEventListener('click', function () {
        container.removeChild(newRow);
    });
});

document.querySelectorAll('.fa-times').forEach(function (button) {
    button.addEventListener('click', function () {
        var row = button.closest('.row-item');
        row.parentNode.removeChild(row);
    });
})



//document.getElementById('add-row-btn3').addEventListener('click', function () {
//    var container = document.getElementById('rows-container');
//    var rowCount = container.children.length;
//    console.log('Current row count:', rowCount); // Debugging log

//    var newRow = document.createElement('div');
//    newRow.classList.add('card', 'rounded-j');
//    newRow.setAttribute('data-index', rowCount);
//    newRow.innerHTML = `
//        <div class="row">
//            <div class="col-md-2">
//                <div class="form-group">
//                    <label class="control-label">Pno</label>
//                    <input class="form-control pno-input" type="text" name="appProjectTeams[${rowCount}].Pno" />
//                </div>
//            </div>
//            <div class="col-md-2">
//                <div class="form-group">
//                    <label class="control-label">Name</label>
//                    <input class="form-control name-input" readonly name="appProjectTeams[${rowCount}].Name" />
//                </div>
//            </div>
//            <div class="col-md-2">
//                <label class="control-label">Type</label>
//                <select class="form-control type-select">
//                    <option value="">---select---</option>
//                    <option value="Leader">Leader</option>
//                    <option value="Member">Member</option>
//                </select>
//            </div>
//            <div class="col-md-2">
//                <div class="form-group">
//                    <i class="fa fa-times fa-lg" aria-hidden="true" style="color:red;margin-top:25px;"></i>
//                </div>
//            </div>

//        </div>`;

//    container.appendChild(newRow);

//    // Add event listener to the newly added row's delete icon
//    newRow.querySelector('.fa-times').addEventListener('click', function () {
//        container.removeChild(newRow);
//    });

//    // Add event listener to the newly added row's type select dropdown
//    newRow.querySelector('.type-select').addEventListener('change', function () {
//        updateTypeSelection();
//    });


//    // Add event listener to the newly added Pno input
//    newRow.querySelector('.pno-input').addEventListener('input', function () {
//        var pnoInput = this;
//        var pnoValue = pnoInput.value;
//        var nameInput = pnoInput.closest('.row').querySelector('.name-input');

//        // Find the corresponding Ename based on the Pno
//        var match = pnoEnameList.find(function (item) {
//            return item.Pno === pnoValue;
//        });

//        if (match) {
//            nameInput.value = match.Ename;
//        } else {
//            nameInput.value = ''; // Clear the name input if no match is found
//        }
//    });
//});

//document.querySelectorAll('.fa-times').forEach(function (button) {
//    button.addEventListener('click', function () {
//        var row = button.closest('.row-item');
//        row.parentNode.removeChild(row);
//    });
//})

// Function to ensure only one Leader is selected
function updateTypeSelection() {
    var container = document.getElementById('rows-container');
    var selects = container.querySelectorAll('.type-select');

    var leaderFound = false; // Flag to check if leader is already selected

    selects.forEach(function (select) {
        if (select.value === 'Leader') {
            if (leaderFound) {
                select.value = 'Member'; // Set to Member if another Leader is found
            } else {
                leaderFound = true; // Mark that Leader is selected
            }
        }
    });
}


//function toggleForm() {
//    var formContainer = document.getElementById('formContainer');
//    if (formContainer.style.display === "none") {
//        formContainer.style.display = "block";
//    } else {
//        formContainer.style.display = "none";
//    }
//}


