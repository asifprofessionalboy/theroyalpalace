﻿







//for visiblity of add new form




function toggleForm() {
   
}

//function toggleEditForm() {
//    var addFormContainer = document.getElementById('addFormContainer');
//    var editFormContainer = document.getElementById('editFormContainer');

//    if (editFormContainer.style.display === 'none' || editFormContainer.style.display === '') {
//        editFormContainer.style.display = 'block';
//        addFormContainer.style.display = 'none';
//    } else {
//        editFormContainer.style.display = 'none';
//    }
//}


document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.contact_form_submit').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();  // Prevent the default link navigation

            const itemId = this.getAttribute('data-id');
            console.log('Item ID:', itemId);  // Check if ID is correct

            // Make an AJAX call to delete the item
            fetch(`/Master/ProjectCategoryDelete/${itemId}`, {
                method: 'GET'
            })
                .then(response => {
                    if (response.ok) {
                        Swal.fire({
                            title: "Data Deleted Successfully",
                            width: 600,
                            padding: "3em",
                            color: "#dc3545",
                            background: "#fff url('path/to/image.png')",
                            backdrop: `
                            rgba(0,0,123,0.4)
                            url("path/to/DSP.jpg")
                            left top
                            no-repeat
                        `,
                            timer: 5000
                        });

                        // Optionally, remove the deleted item from the DOM
                        this.closest('tr').remove();  // Adjust the selector as per your HTML structure
                    } else {
                        console.error('Failed to delete the item.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });
    });
});


document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.DeleteBtn').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();  // Prevent the default link navigation

            const itemId = this.getAttribute('data-id');
            console.log('Item ID:', itemId);  // Check if ID is correct

            // Make an AJAX call to delete the item
            fetch(`/Master/UserRoleDelete/${itemId}`, {
                method: 'GET'
            })
                .then(response => {
                    if (response.ok) {
                        Swal.fire({
                            title: "Data Deleted Successfully",
                            width: 600,
                            padding: "3em",
                            color: "#dc3545",
                            background: "#fff url('path/to/image.png')",
                            backdrop: `
                            rgba(0,0,123,0.4)
                            url("path/to/DSP.jpg")
                            left top
                            no-repeat
                        `,
                            timer: 5000
                        });

                        // Optionally, remove the deleted item from the DOM
                        this.closest('tr').remove();  // Adjust the selector as per your HTML structure
                    } else {
                        console.error('Failed to delete the item.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });
    });
});


document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.contact_form_submit').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();  // Prevent the default link navigation

            const itemId = this.getAttribute('data-id');
            console.log('Item ID:', itemId);  // Check if ID is correct

            // Make an AJAX call to delete the item
            fetch(`/Master/ProjectCategoryDelete/${itemId}`, {
                method: 'GET'
            })
                .then(response => {
                    if (response.ok) {
                        Swal.fire({
                            title: "Data Deleted Successfully",
                            width: 600,
                            padding: "3em",
                            color: "#dc3545",
                            background: "#fff url('path/to/image.png')",
                            backdrop: `
                            rgba(0,0,123,0.4)
                            url("path/to/DSP.jpg")
                            left top
                            no-repeat
                        `,
                            timer: 5000
                        });

                        // Optionally, remove the deleted item from the DOM
                        this.closest('tr').remove();  // Adjust the selector as per your HTML structure
                    } else {
                        console.error('Failed to delete the item.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });
    });
});





//$(document).ready(function () {
//    //$("#SaveBtn").click(function (event) {
//    //    var form = $("#form");

//    //    // Prevent form submission
//    //    event.preventDefault();

//    //    var isValid = true;

//    //    // Validate all input fields and select fields, excluding buttons and radio buttons
//    //    form.find(':input:not(:button):not(:submit):not(:radio), select').each(function () {
//    //        if ($(this).val().trim() === '') {
//    //            $(this).addClass('is-invalid');
//    //            isValid = false;
//    //        } else {
//    //            $(this).removeClass('is-invalid');
//    //        }
//    //    });

//        // Handle radio button validation separately
//        var selectedValue = $('input[name="benefitType"]:checked').val();
//        if (!selectedValue) {
//            // If no radio button is selected, consider it invalid
//            isValid = false;
//        } else {
//            // If a radio button is selected, remove any validation error classes from radio buttons
//            $('input[name="benefitType"]').removeClass('is-invalid');
//        }

//        // If the form is valid, show the success message and submit it
//        if (isValid) {
//            Swal.fire({
//                title: "Data Added Successfully",
//                width: 600,
//                padding: "3em",
//                color: "#28a745",
//                background: "#fff url('path/to/image.png')",
//                backdrop: `
//                    rgba(0,0,123,0.4)
//                    url("path/to/DSP.jpg")
//                    left top
//                    no-repeat
//                `,
//                timer: 5000
//            }).then(() => {
//                // Only submit the form if the validation was successful and the success message was shown
//                form.submit();
//            });
//        }
//    });

//    $("#DraftBtn").click(function (event) {
//        var form = $("#form");

//        // Prevent form submission
//        event.preventDefault();

//        // Directly submit the form without validation or success message
//        form.submit();
//    });
//});





var formStatus = '';

function setSubmitFlag(status) {
    formStatus = status;
    document.getElementById('SubmitFlag').value = status;
}

document.getElementById('form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission

    if (formStatus === 'Save as Draft') {
        // Directly submit the form without validation
        this.submit();
        return;
    }

    var isValid = true;
    var elements = this.querySelectorAll('input, select, textarea');

    elements.forEach(function (element) {
        // Skip validation for specific fields
        if (element.id === 'ApprovalFile' || element.id === 'dropdown-template') {
            return;
        }

        // Check display property of 'otherbenefits' element
        if (element.id === 'otherbenefits') {
            var otherBenefitsElement = document.getElementById('otherbenefits');
            if (otherBenefitsElement.style.display === 'none') {
                // Skip validation if 'otherbenefits' is not visible
                return;
            }
        }

        if (element.value.trim() === '') {
            isValid = false;
            element.classList.add('is-invalid');
            var errorSpan = element.nextElementSibling;
            if (errorSpan && errorSpan.tagName.toLowerCase() === 'span') {
                
            }
        } else {
            element.classList.remove('is-invalid');
            var errorSpan = element.nextElementSibling;
            if (errorSpan && errorSpan.tagName.toLowerCase() === 'span') {
                errorSpan.textContent = '';
            }
        }
    });


    if (isValid) {
        Swal.fire({
            title: "Data Saved Successfully",
            width: 600,
            padding: "3em",
            color: "#28a745",
            background: "#fff",
            backdrop: `
                rgba(0,0,123,0.4)
            `,
            timer: 5000
        }).then(() => {
            // Submit the form after the SweetAlert is shown
            this.submit();
        });
    }
});



